from setuptools import setup, find_packages

setup(
    name="practica-npm-MNAfy",                           # Nombre del paquete
    version="0.1.1",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Jhonfypymna",                         # Tu nombre
    author_email="freddy_3_t@hotmail.com",                 # Tu correo electrónico
    url="https://github.com/jhonfy3320/practica-npm-MNAfy",     # URL del proyecto
)